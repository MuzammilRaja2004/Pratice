alert("hello world")

var num = 5
alert(num + "before Increment")
num ++
num = num + 2
alert(num + "after Increment")

var num = 3
alert(num + "before Increment")
num --
num = num + 1
alert(num + "after Increment")


alert("4 plus 2 equals " + 4 + 2);

alert("2 plus 2 equals " + (2 + 2));

var name = prompt("what is your name?")
var username = prompt("What is your Name","ali")
